PROJECT ATO / COMPLETE CURRENT FREECAD PACKAGE

Extract this ZIP, preserving its Project-ATO/cad/ folder structure.
Requires FreeCAD 1.1 or later. On Windows, run cad/OPEN_CURRENT_CAD.cmd.
For a different installation set ATO_FREECAD_EXE to FreeCAD.exe.

Current full reference: cad/stage5/ATO_stage5_reference_full.FCStd
Future concept: cad/stage5/future-interface/ATO_future_interface.FCStd
Before opening the future FCStd in FreeCAD's Python console:
  import sys
  sys.path.insert(0, r"<your extraction>/Project-ATO/cad/stage5/future-interface")
  import ato_future_features
Then open the FCStd. The Windows launcher does this automatically.

The package contains editable native assemblies, feature definitions, opening
macros, current source scripts and mechanical review drawings. It does not
include the entire research repo or every prerequisite for rebuilding the
electronics-derived assemblies. Use the full repository for regeneration.
The saved FCStd geometry is embedded and does not require external STEP files
for inspection. Keep the supplied module alongside the future native model.

For view-only inspection, close without saving display changes. For intentional
edits use Save As to a separately named working copy.

Reference: 600 x 310 x 240 mm incl feet, 260 physical objects.
Separate future can/header: 60 x 58 x 14 mm before leads; 230 physical parts
plus 6 nonphysical allocation volumes. The reference boards do not fit it.
Digital engineering, no manufactured/implanted performance claimed.
All native members retain their published Git bytes. Browser meshes are separate.
