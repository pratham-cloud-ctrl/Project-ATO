PROJECT ATO - COMPLETE REFERENCE ASSEMBLY

Open ATO_Reference_Complete.step in FreeCAD, Fusion or another STEP-capable CAD application.
This neutral CAD exchange contains the same 260 final physical objects as the browser reference viewer: 170 enclosure/board objects and 90 mating-interface objects.
Dimensions are millimetres. It is a mechanical digital reference; not an implant or tested fabricated assembly.
The existing historical 170-object reference STEP remains unchanged in the repository.
Parts and exact source/neutral hashes are supplied in geometry-manifest.json.
